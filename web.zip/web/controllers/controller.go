package controllers

import (
	"github.com/gosdk-example/blockchain"
)

type Application struct {
	Fabric *blockchain.FabricSetup
}
